module com.geometry.utils {
    requires com.geometry.types;
    requires Week10Lab10Zad1a;
}