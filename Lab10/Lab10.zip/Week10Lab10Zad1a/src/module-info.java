module Week10Lab10Zad1a {
    exports com.geometry.types;
}