package zad3;

public class DerivedClass extends BaseClass
{
    @Override
    public void secondMethod()
    {
        System.out.println("Overrided completed!");
    }
}
