package zad3;

public class BaseClass
{
    public void firstMethod()
    {
        System.out.println("Second method called!");
        secondMethod();
    }
    public void secondMethod()
    {
        System.out.println("Second method called!");
    }

}
