module validation {
    exports valid;
}