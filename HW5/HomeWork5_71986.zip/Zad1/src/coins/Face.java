package coins;
//enum class for the coin
public enum Face
{
    HEAD, TAIL;
}
