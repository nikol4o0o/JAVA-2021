package com.iterator;

public interface SelectorForward extends Selector {
    boolean end();
    void next();
}