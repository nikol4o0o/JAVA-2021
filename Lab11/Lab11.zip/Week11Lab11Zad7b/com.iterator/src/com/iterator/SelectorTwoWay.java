package com.iterator;

public interface SelectorTwoWay extends SelectorForward, SelectorBackward {

}
