package com.iterator;

public interface Selector {
    Object current();
}
