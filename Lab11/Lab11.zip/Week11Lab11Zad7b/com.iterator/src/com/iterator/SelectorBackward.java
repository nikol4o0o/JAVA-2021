package com.iterator;

public interface SelectorBackward extends Selector {
    boolean begin();
    void previous();
}

