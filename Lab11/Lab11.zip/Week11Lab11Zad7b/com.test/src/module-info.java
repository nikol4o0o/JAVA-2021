module com.test {
    requires com.iterator;
}