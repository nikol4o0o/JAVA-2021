module com {
    requires services;
    exports com;
}