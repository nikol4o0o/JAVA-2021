package services;

public interface Computable {
    double function(double x);
}
