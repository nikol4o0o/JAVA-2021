module test {
    requires com;
    requires services;
}