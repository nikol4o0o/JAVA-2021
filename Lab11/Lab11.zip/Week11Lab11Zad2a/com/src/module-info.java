module com {
    requires events;
}