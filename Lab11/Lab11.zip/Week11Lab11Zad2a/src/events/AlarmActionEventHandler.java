package events;

public interface AlarmActionEventHandler
{
    void alarmActionPerformed(AlarmEvent args);
}
