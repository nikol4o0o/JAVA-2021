package zad7a;

public interface Selector {
    boolean end();
    Object current();
    void next();
}

