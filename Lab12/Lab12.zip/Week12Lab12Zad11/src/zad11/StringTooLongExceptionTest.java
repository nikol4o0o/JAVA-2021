package zad11;

import java.util.Scanner;

public class StringTooLongExceptionTest {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String text = "";

        while (!text.equals("DONE")) {
            try {
                System.out.print("Enter text ");
                text = input.nextLine();
                if (text.length() >= 20) {
                    throw new StringTooLongException();
                }
            } catch (StringTooLongException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
