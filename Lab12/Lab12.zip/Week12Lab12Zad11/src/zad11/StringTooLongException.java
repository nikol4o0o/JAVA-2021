package zad11;

public class StringTooLongException extends Exception {
    public StringTooLongException() {
        super("The entered string is too long!!!");
    }
}
