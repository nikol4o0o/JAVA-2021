package zad1;

import java.util.Arrays;

public class GenericStackProvider
{
    public class GenericStack<E> {

        private int topIndex=0;
        private E[] array = (E[]) new Object[10];

        public int getSize()
        {
            return topIndex;
        }

        public E peek()
        {
            if(isEmpty())
            {
                return null;
            }
                return array[getSize()-1];
        }

        public void push(E o)
        {
            if(topIndex == array.length)
            {
                expandArray();
            }
            else
            {
                array[topIndex++] = o;
            }
        }

        public E pop() {
           if(isEmpty())
           {
               return null;
           }
            E o = peek();
            array[--topIndex] = null;
            return o;
        }

        public boolean isEmpty() {
            return topIndex==0;
        }

        private void expandArray()
        {
            E[] newArray = (E[])new Object[getSize()*2];
            for (int i = 0; i < array.length; i++)
            {
                newArray[i] = array[i];
            }
            array = newArray;
        }

        @Override
        public String toString() {
            return "stack: " + Arrays.toString(array);
        }
    }

    public <E> GenericStack<E> getGenericStack()
    {
        return new GenericStack<>();
    }

    public static void main(String[] args)
    {
        GenericStackProvider genericStackProvider= new GenericStackProvider();
        GenericStack<Integer> integerGenericStack = genericStackProvider.getGenericStack();
        for (int i = 0; i < 11; i++)
        {
            integerGenericStack.push(i);
            System.out.printf("Pushed %d\n", i);
        }
        System.out.printf("Size %d", integerGenericStack.getSize());

        GenericStack<String> stringGenericStack = genericStackProvider.getGenericStack();
        for (int i = 0; i < 11; i++)
        {
            stringGenericStack.push("Hello");
        }

        System.out.printf("Pushed %s");
    }
}
