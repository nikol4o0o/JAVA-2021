module com.providers {
    exports providers;
    requires com.services;
}